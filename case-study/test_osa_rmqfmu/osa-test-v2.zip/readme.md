In one terminal run (assumes python3):

$ python playback_gazebo_data-test.py -mode drop

In another terminal run (assumes java 11):
$ java -jar fmi2extension-bundle-1.0.0-SNAPSHOT-jar-with-dependencies.jar interpret spec.mabl FMI2Extension.mabl   
